clear all;
close all;

N = 8;
I1 = imread('stereo1.jpg');
I2 = imread('stereo2.jpg');

X1 = ones(2,N); % Empty vector to store the 8 points
X2 = ones(2,N);
F = zeros(3,3);  % Empty matrix to calculate the fundamental matrix

disp('Calculation of the fundamental matrix algorithm by 8 points');
% Step 1 : Manually obtain 8 corresponding points from the two images 
% stereo1 (left) and stereo2 (right)
% In order to save your time for this task, I encourage you to use the
% function: clickPoints
% ---> TODO <---

load('FM1.mat');
load('X4.mat');


% Step 2 : Calculate the fundamental matrix with 8 point algorithm
% Reference: Chapter 11: Multiview Geometry and lecture slides (56-58)
% Completely writing the function is a part of your exercise session. 
% May be you can exploit the function MatF in you exercise subdirectory 
% which is 70% complete.
% ---> TODO <---
load('X3','X4')
load('C:\mlab\sesion3\betterPointsX1X2.mat')
FM1 = MatF1(X1,X2);

% Step 3 : Calculate the Epipoles of two camera
% Reference: Chapter 9, page : Multiview Geometry
% Book chapter download link: http://www.robots.ox.ac.uk/~vgg/hzbook/hzbook2/HZepipolar.pdf
% Use of MATLAB function 'NULL' may be helpful for you.
% ---> TODO <---
close all;
left_image = double(rgb2gray(imread('stereo1.jpg')));
right_image = double(rgb2gray(imread('stereo2.jpg')));

[m n] = size(left_image);

figure(1),imagesc(left_image); colormap(gray); title('Click a point on this Left Image'); 
figure(2),imagesc(right_image); colormap(gray); title('Corresponding Epipolar Line in this Right Image');

list =['r' 'b' 'g' 'y' 'm' 'k' 'w' 'c'];
for i=1:100
    
    % Clicking a point on the left image:
    figure(1);    
    [left_x, left_y] = ginput(1);
    hold on;
    plot(left_x,left_y,'r*');

    % Finding the epipolar line on the right image:
    left_P = [left_x; left_y; 1];

    right_P = FM1*left_P;

    right_epipolar_x=0:n;
    % Using the eqn of line: ax+by+c=0; y = (-c-ax)/b
    right_epipolar_y=(-right_P(3)-right_P(1)*right_epipolar_x)/right_P(2);
    figure(2);
    hold on;
    plot(right_epipolar_x,right_epipolar_y,list(mod(i,8)+1));

    % Now finding the other epipolar line
    % We know that left epipole is the 3rd column of V.
    % We get V from svd of F. F=UDV'
    left_epipole = FV(:,3);
    left_epipole = left_epipole/left_epipole(3);
    
    left_epipolar_x = 1:2*m;
    left_epipolar_y = left_y + (left_epipolar_x-left_x)*(left_epipole(2)-left_y)/(left_epipole(1)-left_x);
    figure(1);
    hold on;
    plot(left_epipolar_x,left_epipolar_y,list(mod(i,8)+1));

end



