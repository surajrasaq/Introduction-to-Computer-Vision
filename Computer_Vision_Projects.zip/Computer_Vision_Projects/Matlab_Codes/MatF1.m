function F=MatF(p1,p2)
% p1,p2 : vectors of coordinates ...x...

% initialisation
A = [];
N=8;


% Write a martix of homogeneous linear system Af=0
load left_image_points;
load right_image_points;
% Write a martix of homogeneous linear system Af=0
% ---> TODO <---
[a b] = size(left_image_points);
for i=1:a
  
    x1 = left_image_points(i,1);
    y1 = left_image_points(i,2);
    x2 = right_image_points(i,1);
    y2 = right_image_points(i,2);
    A(i,:) = [x1*x2 y1*x2 x2 x1*y2 y1*y2 y2 x1 y1 1];
   
end

% Solving the linear system for the estimate of F by SVD
% Ist step: Linear solution
[U,S,V] = svd(A)
Fest = reshape(V(:,end),3,3)

% 2nd step: Constraint enforcement
Fest=Fest';
[U,S,V] = svd(Fest);
F = U*diag([S(1,1) S(2,2) 0])*V';

% Calculate the Epipoles of two cameras
